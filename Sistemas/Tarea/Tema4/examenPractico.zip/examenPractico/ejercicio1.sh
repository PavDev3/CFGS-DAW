#!bin/bash

nombre="Juan"
saludo="Hola"

echo "$saludo $nombre"
