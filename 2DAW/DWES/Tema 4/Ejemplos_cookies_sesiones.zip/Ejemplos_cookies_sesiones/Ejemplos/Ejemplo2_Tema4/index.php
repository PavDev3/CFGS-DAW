<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Ejemplo 2 Tema 4</title>
    </head>
    <body>
        <?php
            //Si la cookie no existe
            if(!isset($_COOKIE["visitas"]))
            {
               setcookie("visitas","1", time() + 3600 * 24); 
               echo "<h1>Bienvenido por primera vez a la web</h1>"; 
            } 
            //Si no es la primera que visitamos esa página
            else{
                //No olvidar hacer casting a entero
                $visitas = (int)$_COOKIE["visitas"];
                $visitas++; //Se actualiza la variable
                setcookie("visitas",$visitas, time() + 3600 * 24);
                echo "<h1>Bienvenido por $visitas vez</h1>";
            }
        ?>  
        
    </body>
</html>
